package com.example.emocare.data

import androidx.room.*
import com.example.emocare.model.EmotionRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface EmotionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: EmotionRecord)

    @Query("SELECT * FROM emotion_records ORDER BY timestamp DESC")
    fun getAll(): Flow<List<EmotionRecord>>

    @Delete
    suspend fun delete(record: EmotionRecord)

    @Query("DELETE FROM emotion_records")
    suspend fun clear()
}
