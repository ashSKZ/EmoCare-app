package com.example.emocare

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.emocare.ui.MainScreen
import com.example.emocare.worker.NotificationWorker
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🔔 Solicita permiso de notificaciones (solo Android 13+)
        requestNotificationPermission()

        // 🕒 Programa notificación diaria
        scheduleDailyNotification(applicationContext)

        // UI principal
        setContent {
            MainScreen()
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS
            val granted = ContextCompat.checkSelfPermission(this, permission)

            if (granted != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(permission), 1001)
            }
        }
    }

    private fun scheduleDailyNotification(context: android.content.Context) {
        val workRequest = PeriodicWorkRequestBuilder<NotificationWorker>(
            24, TimeUnit.HOURS
        )
            .setInitialDelay(10, TimeUnit.SECONDS) // Puedes personalizar esta demora inicial
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "daily_emocare_notification",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            // ✅ Permiso concedido, podrías mostrar un toast si deseas
        }
    }
}
