package com.example.emocare.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.emocare.data.AppDatabase
import com.example.emocare.model.EmotionRecord
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).emotionDao()

    val records = dao.getAll()
        .map { it.groupBy { record -> record.timestamp.toLocalDateString() } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyMap())

    fun delete(record: EmotionRecord) = viewModelScope.launch {
        dao.delete(record)
    }

    fun clear() = viewModelScope.launch {
        dao.clear()
    }
}

// Extension para agrupar por fecha
fun Long.toLocalDateString(): String {
    return java.text.SimpleDateFormat("yyyy-MM-dd").format(this)
}
