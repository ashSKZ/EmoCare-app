package com.example.emocare.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavBackStackEntry
import com.airbnb.lottie.compose.*
import java.net.URLDecoder

@Composable
fun ResultScreen(
    entry: NavBackStackEntry,
    onBack: () -> Unit
) {
    val emotion = entry.arguments?.getString("emotion") ?: "desconocida"
    val confidence = entry.arguments?.getString("confidence")?.toFloatOrNull() ?: 0f
    val recommendationRaw = entry.arguments?.getString("recommendation") ?: ""
    val recommendation = URLDecoder.decode(recommendationRaw, "UTF-8")

    val animationUrl = when (emotion) {
        "alegría" -> "https://assets7.lottiefiles.com/packages/lf20_ky24lmqu.json"
        "tristeza" -> "https://assets4.lottiefiles.com/packages/lf20_qz5au8fc.json"
        "enojo" -> "https://assets6.lottiefiles.com/packages/lf20_lklfm5yj.json"
        "ansiedad" -> "https://assets8.lottiefiles.com/packages/lf20_yrvhufvt.json"
        "calma" -> "https://assets4.lottiefiles.com/packages/lf20_cns1zdtc.json"
        else -> "https://assets1.lottiefiles.com/packages/lf20_usmfx6bp.json" // Default
    }

    val composition by rememberLottieComposition(LottieCompositionSpec.Url(animationUrl))
    val progress by animateLottieCompositionAsState(composition, iterations = LottieConstants.IterateForever)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Resultado emocional", style = MaterialTheme.typography.headlineSmall)

        LottieAnimation(
            composition = composition,
            progress = { progress },
            modifier = Modifier.size(200.dp)
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Emoción: $emotion", style = MaterialTheme.typography.titleLarge)
            Text("Confianza: ${(confidence * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Recomendación:", style = MaterialTheme.typography.labelMedium)
            Text(recommendation, style = MaterialTheme.typography.bodyLarge)
        }

        Button(onClick = onBack) {
            Text("Volver")
        }
    }
}
