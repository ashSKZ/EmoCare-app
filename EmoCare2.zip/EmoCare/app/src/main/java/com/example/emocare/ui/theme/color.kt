package com.example.emocare.ui.theme

import androidx.compose.ui.graphics.Color

val LightBlue = Color(0xFFA3D5FF)
val SkyBlue = Color(0xFFB8E0F9)
val PowderBlue = Color(0xFFC9E4FF)
val LightGrayBlue = Color(0xFFE0F2FF)
val DarkBlue = Color(0xFF5080B0)
val TextColor = Color(0xFF0B2E59)
