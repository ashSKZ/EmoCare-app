package com.example.emocare.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.emocare.data.AppDatabase
import com.example.emocare.data.EmotionRecord
import kotlin.random.Random

data class EmotionResult(
    val emotion: String,
    val confidence: Float,
    val recommendation: String
)

class HomeViewModel : ViewModel() {

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText

    private val _detectedEmotion = MutableStateFlow<EmotionResult?>(null)
    val detectedEmotion: StateFlow<EmotionResult?> = _detectedEmotion

    fun onTextChange(newText: String) {
        _inputText.value = newText
    }

    fun detectEmotion(context: Context) {
        val text = _inputText.value.lowercase()

        val emotion = when {
            text.contains("feliz") || text.contains("contento") || text.contains("alegre") || text.contains("optimista") -> "alegría"
            text.contains("triste") || text.contains("deprimido") || text.contains("melancólico") -> "tristeza"
            text.contains("enojado") || text.contains("molesto") || text.contains("furioso") -> "enojo"
            text.contains("ansioso") || text.contains("nervioso") || text.contains("preocupado") -> "ansiedad"
            text.contains("tranquilo") || text.contains("relajado") || text.contains("sereno") -> "calma"
            else -> listOf("alegría", "tristeza", "enojo", "ansiedad", "calma").random()
        }

        val confidence = Random.nextDouble(0.7, 1.0).toFloat()

        val recommendation = when (emotion) {
            "alegría" -> "¡Qué bueno verte feliz! Comparte tu alegría con alguien especial."
            "tristeza" -> "Tómate un momento para cuidarte. Escribe cómo te sientes."
            "enojo" -> "Respira profundo. Cuenta hasta 10 antes de reaccionar."
            "ansiedad" -> "Prueba una técnica de respiración o haz una pausa consciente."
            "calma" -> "Disfruta de este estado. Tal vez una meditación suave te beneficie."
            else -> "Exprésate libremente y toma un descanso si lo necesitas."
        }

        val result = EmotionResult(emotion, confidence, recommendation)
        _detectedEmotion.value = result

        // ✅ Guardar en base de datos
        val record = EmotionRecord(
            emotion = result.emotion,
            confidence = result.confidence,
            recommendation = result.recommendation,
            inputText = _inputText.value
        )

        val dao = AppDatabase.getDatabase(context).emotionDao()
        CoroutineScope(Dispatchers.IO).launch {
            dao.insert(record)
        }
    }

    fun clearEmotion() {
        _detectedEmotion.value = null
    }
}

