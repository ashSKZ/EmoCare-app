package com.example.emocare.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.emocare.data.UserProfile
import com.example.emocare.viewmodel.ProfileViewModel

@Composable
fun ProfileScreen(viewModel: ProfileViewModel = viewModel()) {
    val profile by viewModel.profile.collectAsState()

    var nickname by remember { mutableStateOf(profile.nickname) }
    var age by remember { mutableStateOf(profile.age.toString()) }
    var selectedAvatar by remember { mutableStateOf(profile.avatarId) }

    val avatarUrls = listOf(
        "https://cdn.pixabay.com/photo/2017/01/31/21/23/avatar-2027366_960_720.png",
        "https://cdn.pixabay.com/photo/2017/01/31/19/07/avatar-2026510_960_720.png",
        "https://cdn.pixabay.com/photo/2017/01/31/19/07/avatar-2026503_960_720.png",
        "https://cdn.pixabay.com/photo/2017/01/31/19/24/happy-2026958_960_720.png",
        "https://cdn.pixabay.com/photo/2017/01/31/19/07/avatar-2026507_960_720.png",
        "https://cdn.pixabay.com/photo/2017/01/31/19/07/avatar-2026505_960_720.png"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    ) {
        Text("Tu Perfil", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = nickname,
            onValueChange = { nickname = it },
            label = { Text("Apodo") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = age,
            onValueChange = { age = it.filter { c -> c.isDigit() } },
            label = { Text("Edad") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text("Selecciona un avatar:", style = MaterialTheme.typography.titleMedium)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            avatarUrls.forEachIndexed { index, url ->
                val isSelected = (index + 1) == selectedAvatar
                val border = if (isSelected) 3.dp else 0.dp

                Image(
                    painter = rememberAsyncImagePainter(url),
                    contentDescription = "Avatar $index",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .selectable(
                            selected = isSelected,
                            onClick = { selectedAvatar = index + 1 }
                        )
                        .padding(border)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                viewModel.save(
                    UserProfile(
                        nickname = nickname,
                        age = age.toIntOrNull() ?: 0,
                        avatarId = selectedAvatar
                    )
                )
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Guardar")
        }
    }
}
