package com.example.emocare.ui.navigation

sealed class NavRoutes(val route: String) {
    object Home : NavRoutes("home")
    object History : NavRoutes("history")
    object Profile : NavRoutes("profile")
    object Result : NavRoutes("result/{emotion}/{confidence}/{recommendation}") {
        fun createRoute(emotion: String, confidence: Float, recommendation: String): String {
            // Codificamos el texto para evitar errores con caracteres especiales
            val encodedRecommendation = java.net.URLEncoder.encode(recommendation, "UTF-8")
            return "result/$emotion/$confidence/$encodedRecommendation"
        }
    }
}
