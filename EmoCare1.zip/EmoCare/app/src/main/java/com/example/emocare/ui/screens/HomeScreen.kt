package com.example.emocare.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.emocare.ui.navigation.NavRoutes
import com.example.emocare.viewmodel.HomeViewModel
import java.net.URLEncoder


@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = viewModel()
) {
    val inputText by viewModel.inputText.collectAsState()
    val detectedEmotion by viewModel.detectedEmotion.collectAsState()
    val isDetectEnabled = inputText.trim().isNotEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "¿Cómo te sientes hoy?",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = inputText,
            onValueChange = viewModel::onTextChange,
            label = { Text("Escribe lo que sientes...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp),
            maxLines = 6,
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(
                onClick = { /* TODO: reconocimiento de voz */ },
                modifier = Modifier
                    .size(72.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, shape = CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Micrófono",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Button(
                onClick = {
                    viewModel.detectEmotion()
                    viewModel.detectedEmotion.value?.let {
                        navController.navigate(
                            NavRoutes.Result.createRoute(
                                it.emotion,
                                it.confidence,
                                URLEncoder.encode(it.recommendation, "UTF-8")
                            )
                        )
                    }
                },
                enabled = isDetectEnabled,
                modifier = Modifier
                    .height(56.dp)
                    .defaultMinSize(minWidth = 180.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Detectar emoción", fontSize = 16.sp)
            }
        }
    }
}
